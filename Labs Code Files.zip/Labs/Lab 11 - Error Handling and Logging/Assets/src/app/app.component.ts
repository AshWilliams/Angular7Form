import { Component } from '@angular/core';
import { HttpService } from './modules/core/services/http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'error-logging';

  constructor(private httpService: HttpService) {}


  throwError(){
    throw new Error('Error validating input');
  }

  throwHttpError() {
    this.httpService.get('urlhere').subscribe();
  }


}
