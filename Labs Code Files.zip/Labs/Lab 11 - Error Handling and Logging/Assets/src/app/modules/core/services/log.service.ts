import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { environment } from '../../../../environments/environment';

@Injectable()
export class LogService {

  constructor(private httpService: HttpService) { }

  logError(message: string, stack: string) {
    if (environment.production) {
      this.httpService.post('logger', { message, stack }).subscribe();
    } else {
      console.log(message, stack);
    }
  }

  writeToLog(message: string) {
    console.log(message);
  }


}
