import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ErrorExractService } from './error-extract.service';
import { LogService } from '../log.service';
import { NotificationService } from './notification.service';
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
    constructor(private injector: Injector) { }
    handleError(error: Error | HttpErrorResponse) {

        const errorService = this.injector.get(ErrorExractService);
        const logger = this.injector.get(LogService);
        const notifier = this.injector.get(NotificationService);

        let message;
        let stackTrace;
        if (error instanceof HttpErrorResponse) {
            // Server Error
            message = errorService.getServerErrorMessage(error);
            stackTrace = errorService.getServerStackTrace(error);
            notifier.showError(message);
        } else {
            // Client Error
            message = errorService.getClientErrorMessage(error);
            stackTrace = errorService.getClientStackTrace(error);
            notifier.showError(message);
        }
        // Always log errors
        logger.logError(message, stackTrace);
        console.error(error);
    }
}

