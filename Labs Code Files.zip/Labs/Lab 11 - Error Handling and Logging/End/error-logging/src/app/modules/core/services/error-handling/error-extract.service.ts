import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { CoreModule } from '../../core.module';
import * as StackTrace from 'stacktrace-js';

@Injectable()
export class ErrorExractService {
    getServerErrorMessage(error: HttpErrorResponse): string {
        return error.message;
    }
    getServerStackTrace(error: HttpErrorResponse): string {
        // your code to handle server side exceptions
        return 'server stack';
    }
    getClientErrorMessage(error: Error): string {

        return error.message ? error.message : error.toString();
    }
    getClientStackTrace(error: Error): string {
        return StackTrace.fromError(error).then(stackframes => {
            const stackString = stackframes
                .splice(0, 20)
                .map(function (sf) {
                    return sf.toString();
                }).join('\n');
        });
    }
}

