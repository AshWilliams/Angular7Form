import { NgModule, ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { LogService } from './services/log.service';
import { HttpService } from './services/http.service';
import { GlobalErrorHandler } from './services/error-handling/global-error-handler.service';
import { ServerErrorInterceptor } from './services/error-handling/server-error.interceptor';
import { NotificationService } from './services/error-handling/notification.service';
import { ErrorExractService } from './services/error-handling/error-extract.service';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule
  ],
  declarations: [],
  providers: [LogService, HttpService, NotificationService, ErrorExractService,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    { provide: HTTP_INTERCEPTORS, useClass: ServerErrorInterceptor, multi: true }
  ]
})
export class CoreModule { }
