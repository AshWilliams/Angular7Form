
import { Injectable } from '@angular/core';
import { HttpService } from '../../core/services/http.service';
import * as _ from 'lodash';

import { MoviesComboItem } from '../models/combos/movies-combo-item';
import { MovieTimesComboItem } from '../models/combos/movie-times-combo-item';
import { Movie } from '../models/movie';
import { ActiveMovie } from '../models/active-movie';
import { SeatingPlan } from '../models/seating/seating-plan';
import { RowDetails } from '../models/seating/row-details';
import { SeatDetails } from '../models/seating/seat-details';
import { OrderDetails } from '../models/order-details';
import { environment } from '../../../../environments/environment';

import { Observable } from 'rxjs';
import { map, switchMap, distinctUntilChanged } from 'rxjs/operators';

import * as fromTickets from '../store';
import * as fromUiActions from '../store/ui/ui.actions';
import * as fromDataActions from '../store/data/data.actions';
import { Store } from '@ngrx/store';


@Injectable()
export class TicketsService {



  constructor(private store: Store<fromTickets.State>) { }


  getMoviesCombo(): Observable<Array<MoviesComboItem>> {
    return this.store.select(fromTickets.getActiveMoviesRepository)
      .pipe(map((x: Array<ActiveMovie>) => {
        return _.uniqBy(_.map(x, 'movie'), (y: Movie) => y.movieId)
          .map(movie => {
            return this.mapMovieToMovieComboItem(movie);
          });
      })
        , distinctUntilChanged()
      );
  }


  private mapMovieToMovieComboItem(movie: Movie): MoviesComboItem {
    return {
      movieId: movie.movieId,
      movieName: movie.movieName
    };
  }

  getMovieTimesCombo(): Observable<Array<MovieTimesComboItem>> {
    // return active movies for the selected movie

    return this.store.select(fromTickets.getSelectedMovieId).pipe(
      switchMap((selectedMovieId: number) => {
        return this.store.select(fromTickets.getActiveMoviesRepository)
          .pipe(

            map((activeMoviesRepository: Array<ActiveMovie>) => {
              return activeMoviesRepository
                .filter((activeMovie: ActiveMovie) =>
                  activeMovie.movie.movieId === selectedMovieId ||
                  activeMovie.movie.movieId === 0)
                .map(activeMovie => {
                  return this.mapActiveMovieToMovieTimesComboItem(activeMovie);
                });
            }),
            distinctUntilChanged()
          );



      }));
  }

  private mapActiveMovieToMovieTimesComboItem(activeMovie: ActiveMovie): MovieTimesComboItem {
    return {
      activeMovieId: activeMovie.activeMovieId,
      date: activeMovie.date,
      time: activeMovie.time,
      venueName: activeMovie.venue.venueName
    };
  }


  setSelectedMovieId(movieId: number) {
    this.store.dispatch(new fromUiActions.SelectMovieId(movieId));
  }

  getSelectedMovieId(): Observable<number> {
      return this.store.select(fromTickets.getSelectedMovieId);
  }

  getSelectedActiveMovie(): Observable<ActiveMovie> {
    return this.store.select(fromTickets.getSelectedMovieId)
      .pipe(
        switchMap((selectedMovieId: number) => {
            return this.store.select(fromTickets.getActiveMoviesRepository)
            .pipe(
                map((activeMoviesRepository: Array<ActiveMovie>) => {
                return activeMoviesRepository
                  .filter((activeMovie: ActiveMovie) =>
                    activeMovie.movie.movieId === selectedMovieId)[0];
              }));

        }),
        distinctUntilChanged()
      );
  }



  get IsMoviesLoaded(): Observable<boolean> {
    return this.store.select(fromTickets.getMoviesLoaded);
  }


  clearState() {
    this.store.dispatch(new fromUiActions.ClearUiState(fromTickets.INITIAL_TICKETS_STATE.ui));
    this.store.dispatch(new fromDataActions.ClearDataState(fromTickets.INITIAL_TICKETS_STATE.data));
  }

  loadActiveMovies() {

    this.clearState();
    this.store.dispatch(new fromDataActions.LoadActiveMovies());

  }


  setSelectedActiveMovieId(activeMovieId: number) {
    this.store.dispatch(new fromUiActions.SelectActiveMovieId(activeMovieId));
  }


  loadActiveMovieSeatPlan() {

    // TODO , do not dispatch if seatplan already loaded
    this.store.dispatch(new fromDataActions.LoadSeatingPlan());

  }


  get IsSeatPlanLoaded(): Observable<boolean> {
    return this.store.select(fromTickets.getSeatPlanLoaded);
  }

  getSeatingPlan(): Observable<SeatingPlan> {
    return this.store.select(fromTickets.getVenueSeatingPlan).pipe(
      distinctUntilChanged()
    );
  }

  selectSeat(seat: SeatDetails, newStatus: number) {
    // const newstate: UiState = _.cloneDeep(this._store.uiState.getValue());

    // find the seat
    // const myrow = this._store.storeData.getValue().VenueSeatingPlan.rows.filter(row => row.rowNumber === seat.rowNumber)[0];
    // const myseat = myrow.seats.filter(s => s.positionId === seat.positionId)[0];
    // myseat.status = newStatus;



    this.store.dispatch(new fromUiActions.SelectSeat({seat: seat, newStatus: newStatus}));


  }


  getSelectedSeats(): Observable<Array<SeatDetails>> {
    return this.store.select(fromTickets.getSelectedSeats).pipe(
      distinctUntilChanged()
    );
  }

  getIsPurchaseCompleted(): Observable<boolean> {
    return this.store.select(fromTickets.getIsPurchaseCompleted);
  }


  completePurchase(fullName: string, email: string, ccNumber: string) {

    this.store.dispatch(new fromUiActions.CompletePurchase({fullName: fullName, email: email, ccNumber: ccNumber}));

  }

//   completePurchase(fullName: string, email: string, ccNumber: string): Observable<boolean> {


//     const newstate: UiState = _.cloneDeep(this._store.uiState.getValue());
//     const newOrder: OrderDetails = {
//       activeMovieId: newstate.selectedActiveMovieId,
//       reservedSeats: newstate.selectedSeats,
//       fullName: fullName,
//       email: email,
//       ccNumber: ccNumber
//     };


//     return Observable.create(observer => {
//       newstate.orderDetails = newOrder;
//       newstate.isPurchaseCompleted = true;
//       newstate.orderId = '5555';
//       this._store.uiState.next(newstate);
//       observer.next(true);
//       observer.complete();
//     });
//   }

  getOrderId(): Observable<string> {

    return this.store.select(fromTickets.getOrderId);

  }

}


