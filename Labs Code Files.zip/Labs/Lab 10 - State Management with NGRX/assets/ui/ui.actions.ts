import { Action } from '@ngrx/store';
import * as fromUi from '../ui';

export enum UiActionTypes {
  SelectMovieId = '[UI] Select Movie ID',
  ClearUiState = '[UI] Clear Ui State',
  SelectActiveMovieId = '[UI] Select Active Movie ID',
  CompletePurchase = '[UI] CompletePurchse',
  LoadActiveMoviesSuccess = '[UI] Load Active Movies Success',
  LoadSeatingPlanSuccess = '[UI] Load Seating Plan Success',
  SelectSeat = '[UI] Select Seat',



}

export class SelectMovieId implements Action {
  readonly type = UiActionTypes.SelectMovieId;
  constructor(public payload: number) { }
}
export class ClearUiState implements Action {
  readonly type = UiActionTypes.ClearUiState;
  constructor(public payload: fromUi.State ) {}

}
export class SelectActiveMovieId implements Action {
  readonly type = UiActionTypes.SelectActiveMovieId;
  constructor(public payload: number) { }
}
export class CompletePurchase implements Action {
  readonly type = UiActionTypes.CompletePurchase;

  constructor(public payload: {}) { }

}
export class LoadActiveMoviesSuccess implements Action {
  readonly type = UiActionTypes.LoadActiveMoviesSuccess;
}

export class LoadSeatingPlanSuccess implements Action {
  readonly type = UiActionTypes.LoadSeatingPlanSuccess;

}
export class SelectSeat implements Action {
  readonly type = UiActionTypes.SelectSeat;
  constructor(public payload: {}) { }

}




export type UiActions = SelectMovieId
                        | ClearUiState
                        | SelectActiveMovieId
                        | CompletePurchase
                        | LoadActiveMoviesSuccess
                        | LoadSeatingPlanSuccess
                        | SelectSeat;
