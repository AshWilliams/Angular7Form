import { Action, createSelector } from '@ngrx/store';
import { UiActions, UiActionTypes } from './ui.actions';
import { cloneDeep } from 'lodash';
import { SeatDetails } from '../../models/seating/seat-details';
import { OrderDetails } from '../../models/order-details';


export interface State {
  selectedMovieId: number;
  selectedActiveMovieId: number;
  moviesLoaded: boolean;
  seatPlanLoaded: boolean;
  selectedSeats: Array<SeatDetails>;
  isPurchaseCompleted: boolean;
  orderDetails: OrderDetails;
  orderId: string;
}

export const initialState: State = {
  selectedMovieId: null,
  selectedActiveMovieId: null,
  moviesLoaded: false,
  seatPlanLoaded: false,
  selectedSeats: new Array<SeatDetails>(),
  isPurchaseCompleted: false,
  orderDetails: <OrderDetails>{},
  orderId: null

};

export function reducer(state = initialState, action: UiActions): State {

  let newState: State;

  switch (action.type) {

    // case DataActionTypes.Load:
    //   return state;


    case UiActionTypes.SelectMovieId:
      newState = { ...state, selectedMovieId: action.payload};
      break;

      case UiActionTypes.SelectActiveMovieId:
      newState = { ...state, selectedActiveMovieId: action.payload};
      break;

    case UiActionTypes.ClearUiState:
      newState = { ...state, ...action.payload };
      break;

      case UiActionTypes.LoadActiveMoviesSuccess:
      newState = { ...state, selectedMovieId: null, selectedActiveMovieId: null, moviesLoaded: true};
      break;

      case UiActionTypes.LoadSeatingPlanSuccess:
      newState = { ...state, seatPlanLoaded: true};
      break;

      case UiActionTypes.SelectSeat:
          const seat = action.payload['seat'];
          const newStatus = action.payload['newStatus'];


          if (newStatus === 9) {
            newState = {...state, selectedSeats: [...state.selectedSeats, seat]};
          }

          if (newStatus === 1) {
            const index = state.selectedSeats.indexOf(seat);
            if (index !== -1) {
              newState = {...state, selectedSeats: [...state.selectedSeats.slice(0, index),
                                                    ...state.selectedSeats.slice(index + 1)]};
            }


          }
      break;


      case UiActionTypes.CompletePurchase:
        const newOrder: OrderDetails = {
              activeMovieId: state.selectedActiveMovieId,
               reservedSeats: state.selectedSeats,
               fullName: action.payload['fullName'],
               email: action.payload['email'],
               ccNumber: action.payload['ccNumber']
             };
        newState = {...state, orderDetails: newOrder, isPurchaseCompleted: true, orderId: '555'};

      break;

    default:
      return state;
  }

  return newState;
}


// Selectors !


export const getSelectedMovieId = (state: State) => state.selectedMovieId;
export const getSelectedActiveMovieId = (state: State) => state.selectedActiveMovieId;
export const getMoviesLoaded = (state: State) => state.moviesLoaded;
export const getSeatPlanLoaded = (state: State) => state.seatPlanLoaded;
export const getSelectedSeats = (state: State) => state.selectedSeats;
export const getIsPurchaseCompleted = (state: State) => state.isPurchaseCompleted;
export const getOrderDetails = (state: State) => state.orderDetails;
export const getOrderId = (state: State) => state.orderId;
