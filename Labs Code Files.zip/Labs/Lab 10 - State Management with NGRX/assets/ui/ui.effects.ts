import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import * as fromUiActions from './ui.actions';
import {  map } from 'rxjs/operators';

@Injectable()
export class TicketsUiEffects {



  constructor(private actions$: Actions) { }
}
