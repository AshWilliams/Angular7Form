import { Action } from '@ngrx/store';
import * as fromData from '../data';
import { ActiveMovie } from '../../models/active-movie';
import { SeatingPlan } from '../../models/seating/seating-plan';


export enum DataActionTypes {
  ClearDataState = '[DATA] Clear Data State',
  LoadActiveMovies = '[Data] Load Active Movies',
  LoadActiveMoviesSuccess = '[Data] Load Active Movies Success',
  LoadSeatingPlan = '[Data] Load Seating Plan',
  LoadSeatingPlanSuccess = '[Data] Load Seating Plan Success',

}


export class ClearDataState implements Action {
  readonly type = DataActionTypes.ClearDataState;
  constructor(public payload: fromData.State ) {}

}
export class LoadActiveMovies implements Action {
  readonly type = DataActionTypes.LoadActiveMovies;
}
export class LoadActiveMoviesSuccess implements Action {
  readonly type = DataActionTypes.LoadActiveMoviesSuccess;

  constructor(public payload: Array<ActiveMovie>) { }

}

export class LoadSeatingPlan implements Action {
  readonly type = DataActionTypes.LoadSeatingPlan;
}
export class LoadSeatingPlanSuccess implements Action {
  readonly type = DataActionTypes.LoadSeatingPlanSuccess;

  constructor(public payload: SeatingPlan) { }

}


export type DataActions = ClearDataState
                        | LoadActiveMovies
                        | LoadActiveMoviesSuccess
                        | LoadSeatingPlan
                        | LoadSeatingPlanSuccess;

