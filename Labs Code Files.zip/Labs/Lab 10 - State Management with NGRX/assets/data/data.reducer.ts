import { Action, createSelector } from '@ngrx/store';
import { DataActions, DataActionTypes } from './data.actions';
import { cloneDeep } from 'lodash';
import { ActiveMovie } from '../../models/active-movie';
import { SeatingPlan } from '../../models/seating/seating-plan';


export interface State {
  activeMoviesRepository: Array<ActiveMovie>;
  VenueSeatingPlan: SeatingPlan;
}

export const initialState: State = {
  activeMoviesRepository: new Array<ActiveMovie>(),
  VenueSeatingPlan: undefined

};

export function reducer(state = initialState, action: DataActions): State {

  let newState: State;

  switch (action.type) {

    // case DataActionTypes.Load:
    //   return state;


    case DataActionTypes.ClearDataState:
      newState = { ...state, ...action.payload };
      break;

    case DataActionTypes.LoadActiveMoviesSuccess:
      newState = { ...state, activeMoviesRepository: action.payload};
      break;

      case DataActionTypes.LoadSeatingPlanSuccess:
      newState = { ...state, VenueSeatingPlan: action.payload};
      break;


    default:
      return state;
  }

  return newState;
}


// Selectors !
// export const getCustomers = (state: State) => state.customers;

export const getActiveMoviesRepository = (state: State) => state.activeMoviesRepository;
export const getVenueSeatingPlan = (state: State) => state.VenueSeatingPlan;

// export const getSelectedCustomer = createSelector(getCustomers, getSelectedCustomerId,
//   (_customers: Customer[], _selectedId: number) => {
//     return _customers.filter((customer: Customer) => customer.id === _selectedId)[0];
//   });
