import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import * as fromTickets from '../';
import * as fromDataActions from './data.actions';
import * as fromUiActions from '../ui/ui.actions';
import { map, switchMap, withLatestFrom, tap, catchError, distinctUntilChanged } from 'rxjs/operators';
import { HttpService } from '../../../core/services/http.service';
import { ActiveMovie } from '../../models/active-movie';
import { SeatingPlan } from '../../models/seating/seating-plan';
import { Store } from '@ngrx/store';
import { throwError } from 'rxjs';

@Injectable()
export class TicketsDataEffects {

  @Effect()
  loadMovies$ = this.actions$.pipe(
    ofType(fromDataActions.DataActionTypes.LoadActiveMovies),
    switchMap((action) =>
      this.httpService.get<Array<ActiveMovie>>('/GetMovies')),
    switchMap((data: Array<ActiveMovie>) => {
      return [new fromDataActions.LoadActiveMoviesSuccess(data),
      new fromUiActions.LoadActiveMoviesSuccess()];
    })

  );
  @Effect()
  loadSeatingPlan$ = this.actions$.pipe(
    ofType(fromDataActions.DataActionTypes.LoadSeatingPlan),
    withLatestFrom(this.store.select(fromTickets.getSelectedActiveMovieId)),
    distinctUntilChanged(),
    switchMap(([action, selectedActiveMovieId]) =>
      this.httpService.get<SeatingPlan>('/GetSeatingPlan/' + selectedActiveMovieId)),
    switchMap((data: SeatingPlan) => {
      return [new fromDataActions.LoadSeatingPlanSuccess(data),
      new fromUiActions.LoadSeatingPlanSuccess()];
    }),
    catchError(err => {
        console.log(err);
        return throwError(err);
    })

  );

  constructor(private actions$: Actions,
    private store: Store<fromTickets.State>,
     private httpService: HttpService) { }
}
