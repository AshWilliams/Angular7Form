import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { TicketsService } from './tickets.service';
import { Observable } from 'rxjs';
import { filter, take } from 'rxjs/operators';


@Injectable()
export class SelectSeatResolver implements Resolve<boolean> {

    constructor(private ticketsService: TicketsService) {
    }

    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<boolean> {
        this.ticketsService.loadActiveMovieSeatPlan();

        return this.ticketsService.IsSeatPlanLoaded.pipe(
            filter(loaded => loaded),
            take(1)
        );
    }
}
