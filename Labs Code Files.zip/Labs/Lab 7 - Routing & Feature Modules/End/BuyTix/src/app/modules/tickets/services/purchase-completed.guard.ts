import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { TicketsService } from './tickets.service';
import { tap, map } from 'rxjs/operators';
@Injectable()
export class PurchaseCompletedGuard implements CanActivate {
  constructor(private router: Router,
    private ticketsService: TicketsService) { }

    canActivate(
      next: ActivatedRouteSnapshot,
      state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        return this.ticketsService.getIsPurchaseCompleted().pipe(
          tap(res => {
            if (res) {
              this.router.navigate(['/']);
            }
          }),
          map(res => true)
        );
    }
}
