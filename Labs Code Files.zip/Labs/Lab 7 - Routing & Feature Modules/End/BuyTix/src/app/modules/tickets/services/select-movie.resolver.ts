import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { TicketsService } from './tickets.service';
import { Observable } from 'rxjs';
import { filter, take } from 'rxjs/operators';


@Injectable()
export class SelectMovieResolver implements Resolve<boolean> {

    constructor(private ticketsService: TicketsService) {
    }

    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<boolean> {
        this.ticketsService.loadActiveMovies();

        return this.ticketsService.IsMoviesLoaded.pipe(
            filter(loaded => loaded),
            take(1)
        );
    }
}
