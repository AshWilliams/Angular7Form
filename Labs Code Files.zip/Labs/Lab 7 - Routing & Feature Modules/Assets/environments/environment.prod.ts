export const environment = {
  production: true,
  apiEndPoint: 'http://localhost:5000/api/tix'
};
