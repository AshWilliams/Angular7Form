import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SelectMovieContainerComponent } from './components/select-movie/select-movie-container.component';
import { SelectSeatContainerComponent } from './components/select-seat/select-seat-container.component';
import { PersonalDetailsContainerComponent } from './components/personal-details/personal-details-container.component';
import { OrderCompletedContainerComponent } from './components/order-completed/order-completed-container/order-completed-container.component';
import { PurchaseCompletedGuard } from './services/purchase-completed.guard';
import{ SelectMovieResolver } from './services/select-movie.resolver';
import{ SelectSeatResolver } from './services/select-seat.resolver';

const ticketsRoutes: Routes = [
  {path: 'selectmovie', 
      component: SelectMovieContainerComponent,
      resolve: {SelectMovieResolver}
  },
  {path: 'selectseats', 
      component: SelectSeatContainerComponent,
      canActivate: [PurchaseCompletedGuard],
      resolve: {SelectSeatResolver}
  },      
  {path: 'personal-details', 
      component: PersonalDetailsContainerComponent,
      canActivate: [PurchaseCompletedGuard],
  },
  {path: 'order-completed', component: OrderCompletedContainerComponent},
]

@NgModule({
  imports: [RouterModule.forChild(ticketsRoutes)],
  exports: [RouterModule]
})
export class TicketsRoutingModule { }
