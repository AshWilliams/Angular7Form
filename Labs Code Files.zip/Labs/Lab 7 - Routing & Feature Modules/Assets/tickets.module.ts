import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';

import { PurchaseCompletedGuard } from './services/purchase-completed.guard';
import{ SelectMovieResolver } from './services/select-movie.resolver';
import{ SelectSeatResolver } from './services/select-seat.resolver';
import { TicketsService } from './services/tickets.service';

import { SelectMovieContainerComponent } from './components/select-movie/select-movie-container.component';
import { SelectSeatContainerComponent } from './components/select-seat/select-seat-container.component';
import { MovieSelectorComponent } from './components/select-movie/movie-selector.component';
import { MovieDateSelectorComponent } from './components/select-movie/movie-date-selector.component';
import { SeatChartComponent } from './components/select-seat/seat-chart/seat-chart.component';
import { SelectedSeatsComponent } from './components/select-seat/seat-chart/selected-seats.component';
import { SelectedMovieDetailsComponent } from './components/selected-movie-details/selected-movie-details.component';
import { SelectedSeatPipe } from './components/select-seat/seat-chart/selected-seat.pipe';
import { CheckoutFormComponent } from './components/personal-details/checkout/checkout-form.component';
import { PersonalDetailsContainerComponent } from './components/personal-details/personal-details-container.component';
import { OrderCompletedContainerComponent } from './components/order-completed/order-completed-container/order-completed-container.component';

import { TicketsRoutingModule } from './tickets-routing.module';

const ticketsComponents = [SelectMovieContainerComponent, SelectSeatContainerComponent,
                MovieSelectorComponent, MovieDateSelectorComponent,
                SeatChartComponent, SelectedSeatsComponent,
                SelectedMovieDetailsComponent,
                SelectedSeatPipe, CheckoutFormComponent, 
                PersonalDetailsContainerComponent, OrderCompletedContainerComponent
                ]

const ticketsServices = [TicketsService]

@NgModule({
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    TicketsRoutingModule
  ],
  declarations: [ticketsComponents],
  providers: [ticketsServices, PurchaseCompletedGuard, SelectMovieResolver, SelectSeatResolver]
})
export class TicketsModule { }
