import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TicketsService } from '../../../services/tickets.service';
import { SeatDetails } from '../../../models/seating/seat-details';
import { ActivatedRoute, Router } from '@angular/router';
import { ActiveMovie } from '../../../models/active-movie';

@Component({
  selector: 'app-order-completed-container',
  templateUrl: './order-completed-container.component.html',
  styles: []
})
export class OrderCompletedContainerComponent implements OnInit {

  selectedSeats$: Observable<Array<SeatDetails>>;
  activeMovie$: Observable<ActiveMovie>;
  orderId$: Observable<string>;

  constructor(private ticketsService: TicketsService, private router: Router,
      private route: ActivatedRoute) { }
  ngOnInit() {

    this.selectedSeats$ = this.ticketsService.getSelectedSeats();
    this.activeMovie$ = this.ticketsService.getSelectedActiveMovie();
    this.orderId$ = this.ticketsService.getOrderId();

  }


}
