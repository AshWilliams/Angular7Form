export interface CheckoutEventArgs {
    fullName: string;
    email: string;
    ccNumber: string;
}
