export interface MoviesComboItem {
    movieId: number;
    movieName: string;
}
