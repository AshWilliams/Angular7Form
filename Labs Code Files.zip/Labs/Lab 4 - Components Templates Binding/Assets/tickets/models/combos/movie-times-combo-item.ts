export interface MovieTimesComboItem {
    activeMovieId: number;
    date: string;
    time: string;
    venueName: string;
}
