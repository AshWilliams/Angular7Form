export interface Venue {
    venueId: number,
    venueName: string
}
