import { SeatDetails } from './seat-details';
export interface RowDetails {
    rowNumber: number;
    seats: Array<SeatDetails>
}
