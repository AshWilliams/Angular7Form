export interface SeatDetails {
    rowNumber: number;
    positionId: number;
    actualSeatNumber: number;
    status: number;
}
