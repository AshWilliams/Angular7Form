export interface Movie {
    movieId: number;
    movieName: string;
    movieDescription: string;
}
