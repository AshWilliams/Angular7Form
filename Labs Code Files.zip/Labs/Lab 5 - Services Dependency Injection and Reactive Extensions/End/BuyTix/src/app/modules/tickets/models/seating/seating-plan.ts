
import { RowDetails } from './row-details';

export interface SeatingPlan {
    rows: Array<RowDetails>;
}
